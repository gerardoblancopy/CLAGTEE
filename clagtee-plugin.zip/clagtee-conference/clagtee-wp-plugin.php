<?php
/**
 * Plugin Name: CLAGTEE 2026 Conference Site
 * Description: Integración del sitio web de la conferencia CLAGTEE 2026 (React) mediante un shortcode.
 * Version: 1.0.0
 * Author: Antigravity
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function clagtee_enqueue_assets() {
    // Registramos el script de la aplicación React
    // Nota: El nombre del archivo 'index-C8FJ_gzA.js' debe coincidir con el generado en la carpeta dist/assets
    wp_enqueue_script(
        'clagtee-app',
        plugins_url( '/assets/index-C8FJ_gzA.js', __FILE__ ),
        array(),
        '1.0.0',
        true
    );

    // Si tuviéramos archivos CSS específicos en dist/assets, los cargaríamos aquí:
    /*
    wp_enqueue_style(
        'clagtee-styles',
        plugins_url( '/assets/index.css', __FILE__ ),
        array(),
        '1.0.0'
    );
    */
}

// Función para renderizar el contenedor de la App mediante un shortcode [clagtee_site]
function clagtee_render_shortcode() {
    // Cargamos los assets solo cuando se usa el shortcode
    clagtee_enqueue_assets();
    
    // Retornamos el div donde React montará la aplicación
    return '<div id="root"></div>';
}

add_shortcode( 'clagtee_site', 'clagtee_render_shortcode' );
